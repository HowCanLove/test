/// <reference types="@ice/app/types" />
