const { getStylelintConfig } = require('@applint/spec');

module.exports = getStylelintConfig('react');
